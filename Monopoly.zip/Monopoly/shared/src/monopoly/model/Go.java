package monopoly.model;
public class Go extends BoardSpace {
    public Go() {
        super("GO");
    }

    @Override
    public String getType() { return "Go"; }
}
