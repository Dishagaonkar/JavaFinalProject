package monopoly.model;

public class FreeParking extends BoardSpace {
    public FreeParking() { super("Free Parking"); }
    @Override public String getType() { return "Free Parking"; }
}
