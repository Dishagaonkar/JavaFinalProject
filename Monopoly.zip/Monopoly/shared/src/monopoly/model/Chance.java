package monopoly.model;

public class Chance extends BoardSpace {
    public Chance() {
        super("Chance");
    }

    @Override
    public String getType() { return "Chance"; }
}
