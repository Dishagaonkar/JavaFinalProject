package monopoly.model;
public class GoToJail extends BoardSpace {
    public GoToJail() { super("Go To Jail"); }
    @Override public String getType() { return "Go To Jail"; }
}
