package monopoly.net;

/** Sent when the local user clicks “Roll Dice”. */
public record RollDiceReq() implements Message {}
