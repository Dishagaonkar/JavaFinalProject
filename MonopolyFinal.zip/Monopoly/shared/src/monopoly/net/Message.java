package monopoly.net;

import java.io.Serializable;

/** Marker interface for every packet that crosses the wire. */
public interface Message extends Serializable {}
