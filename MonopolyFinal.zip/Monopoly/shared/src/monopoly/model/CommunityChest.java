package monopoly.model;

public class CommunityChest extends BoardSpace {
    public CommunityChest() { super("Community Chest"); }
    @Override public String getType() { return "Community Chest"; }
}