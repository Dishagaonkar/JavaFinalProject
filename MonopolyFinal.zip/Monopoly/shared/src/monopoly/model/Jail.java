package monopoly.model;

import monopoly.server.GameEngine;

public class Jail extends BoardSpace {
    public Jail() {
        super("Jail / Just Visiting");
    }

    @Override
    public String getType() {
        return "Jail";
    }

    @Override
    public void onLand(Player player, GameEngine engine) {
        // If a player lands here through movement, they're just visiting.
        engine.setLastEvent(player.getName() + " is just visiting jail.");
        // No need to send to jail — that's done by the "Go To Jail" square.
    }
}
